#include <asm-generic/resource.h>
