IFC6410 Yocto backup
Timestamp: 20260927-093415

Source:
  /mnt/pve-sata-ssd/ssd-data/backup/ifc6410/github/poky6.0/meta-ifc6410

Parallel layer:
  /mnt/pve-sata-ssd/ssd-data/backup/ifc6410/github/poky6.0/meta-qcom

Build:
  /mnt/pve-sata-ssd/ssd-data/backup/ifc6410/github/poky6.0/build/qcom-armv7a

Contents:
  meta-ifc6410/working-tree.patch
  meta-ifc6410/staged.patch
  meta-ifc6410/untracked/
  meta-ifc6410/patches/
  meta-ifc6410/*.bundle
  meta-qcom/
  build-config/conf/
